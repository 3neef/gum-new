<?php

return [
    'site_title' => 'Gum',
];
