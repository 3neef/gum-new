<aside class="sidenav navbar navbar-vertical navbar-expand-xs border-0 border-radius-xl my-3 fixed-end me-3 rotate-caret  bg-gradient-dark" id="sidenav-main">
    <div class="sidenav-header">
      <i class="fas fa-times p-3 cursor-pointer text-white opacity-5 position-absolute start-0 top-0 d-none d-xl-none" aria-hidden="true" id="iconSidenav"></i>
      <a class="navbar-brand m-0" href="<?php echo e(route('admin.home')); ?>" target="_blank">
        <div style="display: flex;justify-content:center;align-items:center">
            <img src="/images/gum-logo.png" class="w-40 h-40" alt="main_logo">
            
        </div>
        
      </a>
    </div>
    <hr class="horizontal light mt-0 mb-2">
    <div class="collapse navbar-collapse px-0 w-auto " id="sidenav-collapse-main">
      <ul class="navbar-nav">
        <li class="nav-item">
          <a class="nav-link " href="<?php echo e(route("admin.home")); ?>">
            <div class="text-white text-center ms-2 d-flex align-items-center justify-content-center">
              <i class="material-icons-round opacity-10">dashboard</i>
            </div>
            <span class="nav-link-text me-1">لوحة التحكم</span>
          </a>
        </li>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('customer_access')): ?>
                <li class="nav-item">
                    <a href="<?php echo e(route("admin.customers.index")); ?>" class="nav-link <?php echo e(request()->is("admin/customers") || request()->is("admin/customers/*") ? "c-active" : ""); ?>">
                        <i class="fa-fw fas fa-male c-sidebar-nav-icon">

                        </i>
                        <?php echo e(trans('cruds.customer.title')); ?>

                    </a>
                </li>
                <?php endif; ?>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('sale_access')): ?>
                    <li class="nav-item">
                        <a href="<?php echo e(route("admin.sales.index")); ?>" class="nav-link <?php echo e(request()->is("admin/sales") || request()->is("admin/sales/*") ? "c-active" : ""); ?>">
                            <i class="fa-fw fas fa-credit-card c-sidebar-nav-icon">

                            </i>
                            <?php echo e(trans('cruds.sale.title')); ?>

                        </a>
                    </li>
                <?php endif; ?>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('swap_access')): ?>
                    <li class="nav-item">
                        <a href="<?php echo e(route("admin.swaps.index")); ?>" class="nav-link <?php echo e(request()->is("admin/swaps") || request()->is("admin/swaps/*") ? "c-active" : ""); ?>">
                            <i class="fa-fw fas fa-exchange-alt c-sidebar-nav-icon">

                            </i>
                            <?php echo e(trans('cruds.swap.title')); ?>

                        </a>
                    </li>
                <?php endif; ?>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('brand_access')): ?>
                    <li class="nav-item">
                        <a href="<?php echo e(route("admin.brands.index")); ?>" class="nav-link <?php echo e(request()->is("admin/brands") || request()->is("admin/brands/*") ? "c-active" : ""); ?>">
                            <i class="fa-fw far fa-copyright c-sidebar-nav-icon">

                            </i>
                            <?php echo e(trans('cruds.brand.title')); ?>

                        </a>
                    </li>
                <?php endif; ?>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('phone_access')): ?>
                    <li class="nav-item">
                        <a href="<?php echo e(route("admin.phones.index")); ?>" class="nav-link <?php echo e(request()->is("admin/phones") || request()->is("admin/phones/*") ? "c-active" : ""); ?>">
                            <i class="fa-fw fas fa-mobile c-sidebar-nav-icon">

                            </i>
                            <?php echo e(trans('cruds.phone.title')); ?>

                        </a>
                    </li>
                <?php endif; ?>
                <?php if(file_exists(app_path('Http/Controllers/Auth/ChangePasswordController.php'))): ?>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('profile_password_edit')): ?>
                    <li class="nav-item">
                        <a class="nav-link <?php echo e(request()->is('profile/password') || request()->is('profile/password/*') ? 'c-active' : ''); ?>" href="<?php echo e(route('profile.password.edit')); ?>">
                            <i class="fa-fw fas fa-key c-sidebar-nav-icon">
                            </i>
                            <?php echo e(__('تغيير كلمة السر')); ?>

                        </a>
                    </li>
                <?php endif; ?>
                <?php endif; ?>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('user_management_access')): ?>
                <li class="nav-item <?php echo e(request()->is("admin/permissions*") ? "c-show" : ""); ?> <?php echo e(request()->is("admin/roles*") ? "c-show" : ""); ?> <?php echo e(request()->is("admin/users*") ? "c-show" : ""); ?>" disabled>
                    <a class="nav-link" href="#">
                        <i class="fa-fw fas fa-users c-sidebar-nav-icon">
    
                        </i>
                        <?php echo e(trans('cruds.userManagement.title')); ?>

                    </a>
                    <hr class="horizontal my-0">
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('permission_access')): ?>
                            <li class="nav-item">
                                <a href="<?php echo e(route("admin.permissions.index")); ?>" class="nav-link <?php echo e(request()->is("admin/permissions") || request()->is("admin/permissions/*") ? "c-active" : ""); ?>">
                                    <i class="fa-fw fas fa-unlock-alt  c-sidebar-nav-icon">
    
                                    </i>
                                    <?php echo e(trans('cruds.permission.title')); ?>

                                </a>
                            </li>
                        <?php endif; ?>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('role_access')): ?>
                            <li class="nav-item">
                                <a href="<?php echo e(route("admin.roles.index")); ?>" class="nav-link <?php echo e(request()->is("admin/roles") || request()->is("admin/roles/*") ? "c-active" : ""); ?>">
                                    <i class="fa-fw fas fa-briefcase  c-sidebar-nav-icon">
    
                                    </i>
                                    <?php echo e(trans('cruds.role.title')); ?>

                                </a>
                            </li>
                        <?php endif; ?>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('user_access')): ?>
                            <li class="nav-item">
                                <a href="<?php echo e(route("admin.users.index")); ?>" class="nav-link <?php echo e(request()->is("admin/users") || request()->is("admin/users/*") ? "c-active" : ""); ?>">
                                    <i class="fa-fw fas fa-user  c-sidebar-nav-icon">
    
                                    </i>
                                    <?php echo e(trans('cruds.user.title')); ?>

                                </a>
                            </li>
                        <?php endif; ?>
                    
                </li>
            <?php endif; ?>
            </ul>
        </li>
      </ul>
    </div>
  </aside><?php /**PATH C:\Users\10\Desktop\mazin projects\gum\resources\views/partials/menu.blade.php ENDPATH**/ ?>