<?php $__env->startSection('content'); ?>

<div class="card">
    <div class="card-header">
        <?php echo e(trans('global.show')); ?> <?php echo e(trans('cruds.customer.title')); ?>

    </div>

    <div class="card-body">
        <div class="form-group">
            <div class="form-group">
                <a class="btn btn-default" href="<?php echo e(route('admin.customers.index')); ?>">
                    <?php echo e(trans('global.back_to_list')); ?>

                </a>
            </div>
            <table class="table table-bordered table-striped">
                <tbody>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.customer.fields.id')); ?>

                        </th>
                        <td>
                            <?php echo e($customer->id); ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.customer.fields.name')); ?>

                        </th>
                        <td>
                            <?php echo e($customer->name); ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.customer.fields.address')); ?>

                        </th>
                        <td>
                            <?php echo e($customer->address); ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.customer.fields.phone')); ?>

                        </th>
                        <td>
                            <?php echo e($customer->phone); ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.customer.fields.email')); ?>

                        </th>
                        <td>
                            <?php echo e($customer->email); ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.customer.fields.facebook')); ?>

                        </th>
                        <td>
                            <?php echo e($customer->facebook); ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.customer.fields.code')); ?>

                        </th>
                        <td>
                            <?php echo e($customer->code); ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.customer.fields.identification')); ?>

                        </th>
                        <td>
                            <?php $__currentLoopData = $customer->identification; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $media): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <a href="<?php echo e($media->getUrl()); ?>" target="_blank" style="display: inline-block">
                                    <img src="<?php echo e($media->getUrl('thumb')); ?>">
                                </a>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </td>
                    </tr>
                </tbody>
            </table>
            <div class="form-group">
                <a class="btn btn-default" href="<?php echo e(route('admin.customers.index')); ?>">
                    <?php echo e(trans('global.back_to_list')); ?>

                </a>
            </div>
        </div>
    </div>
</div>

<div class="card">
    <div class="card-header">
        <?php echo e(trans('global.relatedData')); ?>

    </div>
    <ul class="nav nav-tabs" role="tablist" id="relationship-tabs">
        <li class="nav-item">
            <a class="nav-link" href="#customer_sales" role="tab" data-toggle="tab">
                <?php echo e(trans('cruds.sale.title')); ?>

            </a>
        </li>
        <li class="nav-item">
            <a class="nav-link" href="#customer_swaps" role="tab" data-toggle="tab">
                <?php echo e(trans('cruds.swap.title')); ?>

            </a>
        </li>
    </ul>
    <div class="tab-content">
        <div class="tab-pane" role="tabpanel" id="customer_sales">
            <?php if ($__env->exists('admin.customers.relationships.customerSales', ['sales' => $customer->customerSales])) echo $__env->make('admin.customers.relationships.customerSales', ['sales' => $customer->customerSales], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
        <div class="tab-pane" role="tabpanel" id="customer_swaps">
            <?php if ($__env->exists('admin.customers.relationships.customerSwaps', ['swaps' => $customer->customerSwaps])) echo $__env->make('admin.customers.relationships.customerSwaps', ['swaps' => $customer->customerSwaps], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.mat', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\10\Desktop\mazin projects\gum\resources\views/admin/customers/show.blade.php ENDPATH**/ ?>