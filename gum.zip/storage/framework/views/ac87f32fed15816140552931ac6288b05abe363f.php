<?php $__env->startSection('title', 'home'); ?>

<?php $__env->startSection('content'); ?>
<div class="content">
    <div class="row">
        <div class="col-lg-12">
                <div class="row">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>
                        <div class="col-lg-4 col-sm-6 mb-lg-0 mb-4">
                          <div class="card">
                            <div class="card-header p-3 pt-2">
                              <div class="icon icon-lg icon-shape bg-gradient-dark shadow-dark text-center border-radius-xl mt-n4 position-absolute">
                                <i class="material-icons opacity-10">send_to_mobile</i>
                              </div>
                              <div class="text-start pt-1">
                                <p class="text-sm mb-0 text-capitalize">عدد مبيعات الهاتف</p>
                                <h4 class="mb-0"><?php echo e($sells->count()); ?></h4>
                              </div>
                            </div>
                            <hr class="dark horizontal my-0">
                           
                          </div>
                        </div>
                        <div class="col-lg-4 col-sm-6 mb-lg-0 mb-4">
                          <div class="card">
                            <div class="card-header p-3 pt-2">
                              <div class="icon icon-lg icon-shape bg-gradient-primary shadow-primary text-center border-radius-xl mt-n4 position-absolute">
                                <i class="material-icons opacity-10">security_update_good
                                </i>
                              </div>
                              <div class="text-start pt-1">
                                <p class="text-sm mb-0 text-capitalize">عدد الهواتف المشتراة</p>
                                <h4 class="mb-0"><?php echo e($buys->count()); ?></h4>
                              </div>
                            </div>
                            <hr class="dark horizontal my-0">
                           
                          </div>
                        </div>
                        <div class="col-lg-4 col-sm-6 mb-lg-0 mb-4">
                          <div class="card">
                            <div class="card-header p-3 pt-2">
                              <div class="icon icon-lg icon-shape bg-gradient-success shadow-success text-center border-radius-xl mt-n4 position-absolute">
                                <i class="material-icons opacity-10">diversity_2
                                </i>
                              </div>
                              <div class="text-start pt-1">
                                <p class="text-sm mb-0 text-capitalize">عدد الزبائن والعملاء</p>
                                <h4 class="mb-0">
                                  <?php echo e($custmers->count()); ?>

                                </h4>
                              </div>
                            </div>
                            <hr class="dark horizontal my-0">
                            
                          </div>
                        </div>
                        <div class="col-lg-4 col-sm-6 mt-4">
                          <div class="card">
                            <div class="card-header p-3 pt-2">
                              <div class="icon icon-lg icon-shape bg-gradient-info shadow-info text-center border-radius-xl mt-n4 position-absolute">
                                <i class="material-icons opacity-10">swap_horizontal_circle
                                </i>
                              </div>
                              <div class="text-start pt-1">
                                <p class="text-sm mb-0 text-capitalize">المقايضات</p>
                                <h4 class="mb-0"><?php echo e($swaps->count()); ?></h4>
                              </div>
                            </div>
                            <hr class="dark horizontal my-0">
                            
                          </div>
                        </div>
                        <div class="col-lg-4 col-sm-6 mb-lg-0 mt-4">
                          <div class="card">
                            <div class="card-header p-3 pt-2">
                              <div class="icon icon-lg icon-shape bg-gradient-dark shadow-dark text-center border-radius-xl mt-n4 position-absolute">
                                <i class="material-icons opacity-10">mobile_friendly

                                </i>
                              </div>
                              <div class="text-start pt-1">
                                <p class="text-sm mb-0 text-capitalize">الهواتف الجديدة</p>
                                <h4 class="mb-0"><?php echo e($new_phones->count()); ?></h4>
                              </div>
                            </div>
                            <hr class="dark horizontal my-0">
                          
                          </div>
                        </div>
                        <div class="col-lg-4 col-sm-6 mb-lg-0 mt-4">
                          <div class="card">
                            <div class="card-header p-3 pt-2">
                              <div class="icon icon-lg icon-shape bg-gradient-primary shadow-primary text-center border-radius-xl mt-n4 position-absolute">
                                <i class="material-icons opacity-10">install_mobile
                                </i>
                              </div>
                              <div class="text-start pt-1">
                                <p class="text-sm mb-0 text-capitalize">الهواتف المستعلة</p>
                                <h4 class="mb-0"><?php echo e($used_phones->count()); ?></h4>
                              </div>
                            </div>
                            <hr class="dark horizontal my-0">
                            
                          </div>
                        </div>
                      </div>

                
           
        </div>
    </div>
</div>

<div class="row my-4">
  <div class="col-lg-12 col-md-6 mb-md-0 mb-4">
    <div class="card">
      <div class="card-header pb-0">
        <div class="row mb-3">
          <div class="col-6">
            <h6>المبيعات</h6>
            <p class="text-sm">
              <i class="fa fa-check text-info" aria-hidden="true"></i>
              <span class="font-weight-bold ms-1">أخر المبيعات</span> هذا الشهر
            </p>
          </div>
          
        </div>
      </div>
      <div class="card-body p-0 pb-2">
        <div class="table-responsive">
          <table class="table align-items-center mb-0">
            <thead>
              <tr>
                <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">العلامة</th>
                <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7 ps-2">الهاتف</th>
                <th class="text-center text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">السعر</th>
                <th class="text-center text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">نوع العملية</th>
              </tr>
            </thead>
            <tbody>
              <?php $__currentLoopData = $sales; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $sale): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr>
                <td>
                  <div class="d-flex px-2 py-1">
                    <div>
                      <?php $__currentLoopData = $sale->phones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <img src="<?php echo e($item->brand->logo->getUrl('thumb')); ?>" class="avatar avatar-sm ms-3">
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    <div class="d-flex flex-column justify-content-center">
                      <h6 class="mb-0 text-sm"> 
                        <?php $__currentLoopData = $sale->phones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php echo e($item->name); ?>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </h6>
                    </div>
                  </div>
                </td>
                <td>
                  <div class="avatar-group mt-2">
                    <a href="javascript:;" class="avatar avatar-xs rounded-circle" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Ryan Tompson">
                      <?php $__currentLoopData = $sale->phones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php $__currentLoopData = $item->images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $media): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <img alt="Image placeholder" src="<?php echo e($media->getUrl('thumb')); ?>">
                        
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </a>
                  </div>
                </td>
                <td class="align-middle text-center text-sm">
                  <span class="text-xs font-weight-bold"> <?php echo e($sale->total_price ?? ''); ?> </span>
                </td>
                <td class="align-middle">
                  <div class="progress-wrapper w-75 mx-auto">
                    <div class="progress-info">
                      <div class="progress-percentage">
                        <span class="text-xs font-weight-bold"> <?php echo e(App\Models\Sale::OPERATION_RADIO[$sale->operation] ?? ''); ?></span>
                      </div>
                    </div>
                  </div>
                </td>
              </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </div>
  
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<?php echo \Illuminate\View\Factory::parentPlaceholder('scripts'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.mat', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\10\Desktop\mazin projects\gum\resources\views/home.blade.php ENDPATH**/ ?>