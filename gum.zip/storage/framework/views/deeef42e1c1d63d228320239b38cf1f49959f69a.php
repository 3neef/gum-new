<?php $__env->startSection('content'); ?>

<div class="card">
    <div class="card-header">
        <?php echo e(trans('global.show')); ?> <?php echo e(trans('cruds.phone.title')); ?>

    </div>

    <div class="card-body">
        <div class="form-group">
            <div class="form-group">
                <a class="btn btn-default" href="<?php echo e(route('admin.phones.index')); ?>">
                    <?php echo e(trans('global.back_to_list')); ?>

                </a>
            </div>
            <div class="invoice-logo">
                <img src="/images/gum-logo.png" class="w-30 h-30" alt="main_logo">
                
            </div>
            <table class="table table-bordered table-striped">
                <tbody>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.phone.fields.id')); ?>

                        </th>
                        <td>
                            <?php echo e($phone->id); ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.phone.fields.name')); ?>

                        </th>
                        <td>
                            <?php echo e($phone->name); ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.phone.fields.brand')); ?>

                        </th>
                        <td>
                            <?php echo e($phone->brand->name ?? ''); ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.phone.fields.state')); ?>

                        </th>
                        <td>
                            <?php echo e(App\Models\Phone::STATE_RADIO[$phone->state] ?? ''); ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.phone.fields.color')); ?>

                        </th>
                        <td>
                            <?php echo e($phone->color); ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.phone.fields.battery')); ?>

                        </th>
                        <td>
                            <?php echo e($phone->battery); ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.phone.fields.space')); ?>

                        </th>
                        <td>
                            <?php echo e($phone->space); ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.phone.fields.ram')); ?>

                        </th>
                        <td>
                            <?php echo e($phone->ram); ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.phone.fields.images')); ?>

                        </th>
                        <td>
                            <?php $__currentLoopData = $phone->images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $media): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <a href="<?php echo e($media->getUrl()); ?>" target="_blank" style="display: inline-block">
                                    <img src="<?php echo e($media->getUrl('thumb')); ?>">
                                </a>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.phone.fields.notes')); ?>

                        </th>
                        <td>
                            <?php echo $phone->notes; ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.phone.fields.price')); ?>

                        </th>
                        <td>
                            <?php echo e($phone->price); ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.phone.fields.serial')); ?>

                        </th>
                        <td>
                            <?php echo e($phone->serial); ?>

                        </td>
                    </tr>
                </tbody>
            </table>
            <div class="form-group">
                <a class="btn btn-default" href="<?php echo e(route('admin.phones.index')); ?>">
                    <?php echo e(trans('global.back_to_list')); ?>

                </a>
            </div>
            <div>
                <div  class="social-links">
                    
                    <span>Gum21th/</span>
                    <i class="fa fa-twitter me-sm-1"></i>
                    <i class="fa fa-telegram me-sm-1"></i>
                    <i class="fab fa-tiktok me-sm-1"></i>
                    <i class="fa fa-instagram me-sm-1"></i>
                    <i class="fa fa-heart me-sm-1"></i>
                </div>
                <div class="whatsapp">
                    <span>0112196778</span>
                    <i class="fa fa-whatsapp me-sm-1"></i>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="card">
    <div class="card-header">
        <?php echo e(trans('global.relatedData')); ?>

    </div>
    <ul class="nav nav-tabs" role="tablist" id="relationship-tabs">
        <li class="nav-item">
            <a class="nav-link" href="#phone1_swaps" role="tab" data-toggle="tab">
                <?php echo e(trans('cruds.swap.title')); ?>

            </a>
        </li>
        <li class="nav-item">
            <a class="nav-link" href="#phone2_swaps" role="tab" data-toggle="tab">
                <?php echo e(trans('cruds.swap.title')); ?>

            </a>
        </li>
        <li class="nav-item">
            <a class="nav-link" href="#phone_sales" role="tab" data-toggle="tab">
                <?php echo e(trans('cruds.sale.title')); ?>

            </a>
        </li>
    </ul>
    <div class="tab-content">
        <div class="tab-pane" role="tabpanel" id="phone1_swaps">
            <?php if ($__env->exists('admin.phones.relationships.phone1Swaps', ['swaps' => $phone->phone1Swaps])) echo $__env->make('admin.phones.relationships.phone1Swaps', ['swaps' => $phone->phone1Swaps], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
        <div class="tab-pane" role="tabpanel" id="phone2_swaps">
            <?php if ($__env->exists('admin.phones.relationships.phone2Swaps', ['swaps' => $phone->phone2Swaps])) echo $__env->make('admin.phones.relationships.phone2Swaps', ['swaps' => $phone->phone2Swaps], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
        <div class="tab-pane" role="tabpanel" id="phone_sales">
            <?php if ($__env->exists('admin.phones.relationships.phoneSales', ['sales' => $phone->phoneSales])) echo $__env->make('admin.phones.relationships.phoneSales', ['sales' => $phone->phoneSales], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.mat', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\10\Desktop\mazin projects\gum\resources\views/admin/phones/show.blade.php ENDPATH**/ ?>