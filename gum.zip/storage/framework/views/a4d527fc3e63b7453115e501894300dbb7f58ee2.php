<?php $__env->startSection('content'); ?>

<div class="card">
    <div class="card-header">
        <?php echo e(trans('global.edit')); ?> <?php echo e(trans('cruds.customer.title_singular')); ?>

    </div>

    <div class="card-body">
        <form method="POST" action="<?php echo e(route("admin.customers.update", [$customer->id])); ?>" enctype="multipart/form-data">
            <?php echo method_field('PUT'); ?>
            <?php echo csrf_field(); ?>
            <div class="form-group">
                <label class="required" for="name"><?php echo e(trans('cruds.customer.fields.name')); ?></label>
                <input class="form-control <?php echo e($errors->has('name') ? 'is-invalid' : ''); ?>" type="text" name="name" id="name" value="<?php echo e(old('name', $customer->name)); ?>" required>
                <?php if($errors->has('name')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('name')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.customer.fields.name_helper')); ?></span>
            </div>
            <div class="form-group">
                <label for="address"><?php echo e(trans('cruds.customer.fields.address')); ?></label>
                <input class="form-control <?php echo e($errors->has('address') ? 'is-invalid' : ''); ?>" type="text" name="address" id="address" value="<?php echo e(old('address', $customer->address)); ?>">
                <?php if($errors->has('address')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('address')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.customer.fields.address_helper')); ?></span>
            </div>
            <div class="form-group">
                <label class="required" for="phone"><?php echo e(trans('cruds.customer.fields.phone')); ?></label>
                <input class="form-control <?php echo e($errors->has('phone') ? 'is-invalid' : ''); ?>" type="text" name="phone" id="phone" value="<?php echo e(old('phone', $customer->phone)); ?>" required>
                <?php if($errors->has('phone')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('phone')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.customer.fields.phone_helper')); ?></span>
            </div>
            <div class="form-group">
                <label for="email"><?php echo e(trans('cruds.customer.fields.email')); ?></label>
                <input class="form-control <?php echo e($errors->has('email') ? 'is-invalid' : ''); ?>" type="text" name="email" id="email" value="<?php echo e(old('email', $customer->email)); ?>">
                <?php if($errors->has('email')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('email')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.customer.fields.email_helper')); ?></span>
            </div>
            <div class="form-group">
                <label for="facebook"><?php echo e(trans('cruds.customer.fields.facebook')); ?></label>
                <input class="form-control <?php echo e($errors->has('facebook') ? 'is-invalid' : ''); ?>" type="text" name="facebook" id="facebook" value="<?php echo e(old('facebook', $customer->facebook)); ?>">
                <?php if($errors->has('facebook')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('facebook')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.customer.fields.facebook_helper')); ?></span>
            </div>
            <div class="form-group">
                <label class="required" for="code"><?php echo e(trans('cruds.customer.fields.code')); ?></label>
                <input class="form-control <?php echo e($errors->has('code') ? 'is-invalid' : ''); ?>" type="text" name="code" id="code" value="<?php echo e(old('code', $customer->code)); ?>" required>
                <?php if($errors->has('code')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('code')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.customer.fields.code_helper')); ?></span>
            </div>
            <div class="form-group">
                <label for="identification"><?php echo e(trans('cruds.customer.fields.identification')); ?></label>
                <div class="needsclick dropzone <?php echo e($errors->has('identification') ? 'is-invalid' : ''); ?>" id="identification-dropzone">
                </div>
                <?php if($errors->has('identification')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('identification')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.customer.fields.identification_helper')); ?></span>
            </div>
            <div class="form-group">
                <button class="btn btn-danger" type="submit">
                    <?php echo e(trans('global.save')); ?>

                </button>
            </div>
        </form>
    </div>
</div>



<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script>
    var uploadedIdentificationMap = {}
Dropzone.options.identificationDropzone = {
    url: '<?php echo e(route('admin.customers.storeMedia')); ?>',
    maxFilesize: 20, // MB
    acceptedFiles: '.jpeg,.jpg,.png,.gif',
    addRemoveLinks: true,
    headers: {
      'X-CSRF-TOKEN': "<?php echo e(csrf_token()); ?>"
    },
    params: {
      size: 20,
      width: 4096,
      height: 4096
    },
    success: function (file, response) {
      $('form').append('<input type="hidden" name="identification[]" value="' + response.name + '">')
      uploadedIdentificationMap[file.name] = response.name
    },
    removedfile: function (file) {
      console.log(file)
      file.previewElement.remove()
      var name = ''
      if (typeof file.file_name !== 'undefined') {
        name = file.file_name
      } else {
        name = uploadedIdentificationMap[file.name]
      }
      $('form').find('input[name="identification[]"][value="' + name + '"]').remove()
    },
    init: function () {
<?php if(isset($customer) && $customer->identification): ?>
      var files = <?php echo json_encode($customer->identification); ?>

          for (var i in files) {
          var file = files[i]
          this.options.addedfile.call(this, file)
          this.options.thumbnail.call(this, file, file.preview)
          file.previewElement.classList.add('dz-complete')
          $('form').append('<input type="hidden" name="identification[]" value="' + file.file_name + '">')
        }
<?php endif; ?>
    },
     error: function (file, response) {
         if ($.type(response) === 'string') {
             var message = response //dropzone sends it's own error messages in string
         } else {
             var message = response.errors.file
         }
         file.previewElement.classList.add('dz-error')
         _ref = file.previewElement.querySelectorAll('[data-dz-errormessage]')
         _results = []
         for (_i = 0, _len = _ref.length; _i < _len; _i++) {
             node = _ref[_i]
             _results.push(node.textContent = message)
         }

         return _results
     }
}
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.mat', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\10\Desktop\mazin projects\gum\resources\views/admin/customers/edit.blade.php ENDPATH**/ ?>