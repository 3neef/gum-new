<?php $__env->startSection('content'); ?>

<div class="card">
    <div class="card-header">
        <?php echo e(trans('global.create')); ?> <?php echo e(trans('cruds.phone.title_singular')); ?>

    </div>

    <div class="card-body">
        <form method="POST" action="<?php echo e(route("admin.phones.store")); ?>" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <div class="form-group">
                <label class="required" for="name"><?php echo e(trans('cruds.phone.fields.name')); ?></label>
                <input class="form-control <?php echo e($errors->has('name') ? 'is-invalid' : ''); ?>" type="text" name="name" id="name" value="<?php echo e(old('name', '')); ?>" required>
                <?php if($errors->has('name')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('name')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.phone.fields.name_helper')); ?></span>
            </div>
            <div class="form-group">
                <label class="required" for="brand_id"><?php echo e(trans('cruds.phone.fields.brand')); ?></label>
                <select class="form-control select2 <?php echo e($errors->has('brand') ? 'is-invalid' : ''); ?>" name="brand_id" id="brand_id" required>
                    <?php $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $entry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($id); ?>" <?php echo e(old('brand_id') == $id ? 'selected' : ''); ?>><?php echo e($entry); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php if($errors->has('brand')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('brand')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.phone.fields.brand_helper')); ?></span>
            </div>
            <div class="form-group">
                <label class="required"><?php echo e(trans('cruds.phone.fields.state')); ?></label>
                <?php $__currentLoopData = App\Models\Phone::STATE_RADIO; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="form-check <?php echo e($errors->has('state') ? 'is-invalid' : ''); ?>">
                        <input class="form-check-input" type="radio" id="state_<?php echo e($key); ?>" name="state" value="<?php echo e($key); ?>" <?php echo e(old('state', 'new') === (string) $key ? 'checked' : ''); ?> required>
                        <label class="form-check-label" for="state_<?php echo e($key); ?>"><?php echo e($label); ?></label>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php if($errors->has('state')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('state')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.phone.fields.state_helper')); ?></span>
            </div>
            <div class="form-group">
                <label for="color"><?php echo e(trans('cruds.phone.fields.color')); ?></label>
                <input class="form-control <?php echo e($errors->has('color') ? 'is-invalid' : ''); ?>" type="text" name="color" id="color" value="<?php echo e(old('color', '')); ?>">
                <?php if($errors->has('color')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('color')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.phone.fields.color_helper')); ?></span>
            </div>
            <div class="form-group">
                <label for="battery"><?php echo e(trans('cruds.phone.fields.battery')); ?></label>
                <input class="form-control <?php echo e($errors->has('battery') ? 'is-invalid' : ''); ?>" type="number" name="battery" id="battery" value="<?php echo e(old('battery', '')); ?>" step="1">
                <?php if($errors->has('battery')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('battery')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.phone.fields.battery_helper')); ?></span>
            </div>
            <div class="form-group">
                <label for="space"><?php echo e(trans('cruds.phone.fields.space')); ?></label>
                <input class="form-control <?php echo e($errors->has('space') ? 'is-invalid' : ''); ?>" type="number" name="space" id="space" value="<?php echo e(old('space', '')); ?>" step="1">
                <?php if($errors->has('space')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('space')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.phone.fields.space_helper')); ?></span>
            </div>
            <div class="form-group">
                <label for="ram"><?php echo e(trans('cruds.phone.fields.ram')); ?></label>
                <input class="form-control <?php echo e($errors->has('ram') ? 'is-invalid' : ''); ?>" type="text" name="ram" id="ram" value="<?php echo e(old('ram', '')); ?>">
                <?php if($errors->has('ram')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('ram')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.phone.fields.ram_helper')); ?></span>
            </div>
            <div class="form-group">
                <label for="images"><?php echo e(trans('cruds.phone.fields.images')); ?></label>
                <div class="needsclick dropzone <?php echo e($errors->has('images') ? 'is-invalid' : ''); ?>" id="images-dropzone">
                </div>
                <?php if($errors->has('images')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('images')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.phone.fields.images_helper')); ?></span>
            </div>
            <div class="form-group">
                <label for="notes"><?php echo e(trans('cruds.phone.fields.notes')); ?></label>
                <textarea class="form-control ckeditor <?php echo e($errors->has('notes') ? 'is-invalid' : ''); ?>" name="notes" id="notes"><?php echo old('notes'); ?></textarea>
                <?php if($errors->has('notes')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('notes')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.phone.fields.notes_helper')); ?></span>
            </div>
            <div class="form-group">
                <label for="price"><?php echo e(trans('cruds.phone.fields.price')); ?></label>
                <input class="form-control <?php echo e($errors->has('price') ? 'is-invalid' : ''); ?>" type="text" name="price" id="price" value="<?php echo e(old('price', '')); ?>">
                <?php if($errors->has('price')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('price')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.phone.fields.price_helper')); ?></span>
            </div>
            <div class="form-group">
                <label for="serial"><?php echo e(trans('cruds.phone.fields.serial')); ?></label>
                <input class="form-control <?php echo e($errors->has('serial') ? 'is-invalid' : ''); ?>" type="text" name="serial" id="serial" value="<?php echo e(old('serial', '')); ?>">
                <?php if($errors->has('serial')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('serial')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.phone.fields.serial_helper')); ?></span>
            </div>
            <div class="form-group">
                <button class="btn btn-danger" type="submit">
                    <?php echo e(trans('global.save')); ?>

                </button>
            </div>
        </form>
    </div>
</div>



<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script>
    var uploadedImagesMap = {}
Dropzone.options.imagesDropzone = {
    url: '<?php echo e(route('admin.phones.storeMedia')); ?>',
    maxFilesize: 50, // MB
    acceptedFiles: '.jpeg,.jpg,.png,.gif',
    addRemoveLinks: true,
    headers: {
      'X-CSRF-TOKEN': "<?php echo e(csrf_token()); ?>"
    },
    params: {
      size: 50,
      width: 4096,
      height: 4096
    },
    success: function (file, response) {
      $('form').append('<input type="hidden" name="images[]" value="' + response.name + '">')
      uploadedImagesMap[file.name] = response.name
    },
    removedfile: function (file) {
      console.log(file)
      file.previewElement.remove()
      var name = ''
      if (typeof file.file_name !== 'undefined') {
        name = file.file_name
      } else {
        name = uploadedImagesMap[file.name]
      }
      $('form').find('input[name="images[]"][value="' + name + '"]').remove()
    },
    init: function () {
<?php if(isset($phone) && $phone->images): ?>
      var files = <?php echo json_encode($phone->images); ?>

          for (var i in files) {
          var file = files[i]
          this.options.addedfile.call(this, file)
          this.options.thumbnail.call(this, file, file.preview ?? file.preview_url)
          file.previewElement.classList.add('dz-complete')
          $('form').append('<input type="hidden" name="images[]" value="' + file.file_name + '">')
        }
<?php endif; ?>
    },
     error: function (file, response) {
         if ($.type(response) === 'string') {
             var message = response //dropzone sends it's own error messages in string
         } else {
             var message = response.errors.file
         }
         file.previewElement.classList.add('dz-error')
         _ref = file.previewElement.querySelectorAll('[data-dz-errormessage]')
         _results = []
         for (_i = 0, _len = _ref.length; _i < _len; _i++) {
             node = _ref[_i]
             _results.push(node.textContent = message)
         }

         return _results
     }
}

</script>
<script>
    $(document).ready(function () {
  function SimpleUploadAdapter(editor) {
    editor.plugins.get('FileRepository').createUploadAdapter = function(loader) {
      return {
        upload: function() {
          return loader.file
            .then(function (file) {
              return new Promise(function(resolve, reject) {
                // Init request
                var xhr = new XMLHttpRequest();
                xhr.open('POST', '<?php echo e(route('admin.phones.storeCKEditorImages')); ?>', true);
                xhr.setRequestHeader('x-csrf-token', window._token);
                xhr.setRequestHeader('Accept', 'application/json');
                xhr.responseType = 'json';

                // Init listeners
                var genericErrorText = `Couldn't upload file: ${ file.name }.`;
                xhr.addEventListener('error', function() { reject(genericErrorText) });
                xhr.addEventListener('abort', function() { reject() });
                xhr.addEventListener('load', function() {
                  var response = xhr.response;

                  if (!response || xhr.status !== 201) {
                    return reject(response && response.message ? `${genericErrorText}\n${xhr.status} ${response.message}` : `${genericErrorText}\n ${xhr.status} ${xhr.statusText}`);
                  }

                  $('form').append('<input type="hidden" name="ck-media[]" value="' + response.id + '">');

                  resolve({ default: response.url });
                });

                if (xhr.upload) {
                  xhr.upload.addEventListener('progress', function(e) {
                    if (e.lengthComputable) {
                      loader.uploadTotal = e.total;
                      loader.uploaded = e.loaded;
                    }
                  });
                }

                // Send request
                var data = new FormData();
                data.append('upload', file);
                data.append('crud_id', '<?php echo e($phone->id ?? 0); ?>');
                xhr.send(data);
              });
            })
        }
      };
    }
  }

  var allEditors = document.querySelectorAll('.ckeditor');
  for (var i = 0; i < allEditors.length; ++i) {
    ClassicEditor.create(
      allEditors[i], {
        extraPlugins: [SimpleUploadAdapter]
      }
    );
  }
});
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.mat', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\10\Desktop\mazin projects\gum\resources\views/admin/phones/create.blade.php ENDPATH**/ ?>